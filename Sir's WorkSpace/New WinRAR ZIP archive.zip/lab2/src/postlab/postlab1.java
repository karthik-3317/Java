package postlab;

public class postlab1 {
	 public static String even_or_odd(int number) {
	        return number%2 ==0 ? "Even" : "Odd";
	    }

}
