package inlab;
public class inlab1 {
	public int Add(int number1, int number2)
	{		
		return (number1 + number2);
	}	
}
