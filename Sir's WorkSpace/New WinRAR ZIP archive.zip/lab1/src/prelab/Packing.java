package prelab;

public interface Packing 
{
	 public String pack();
}
