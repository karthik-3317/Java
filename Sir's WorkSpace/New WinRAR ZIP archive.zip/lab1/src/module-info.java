/**
 * 
 */
/**
 * @author vinee
 *
 */
module lab1 {
}