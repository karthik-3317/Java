package skill1_Q2;

public interface Shopper
{
	int visit(Pen pen);
	 int visit(Notebook notebook);
}
