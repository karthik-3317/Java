package skill1_Q2;

public interface Cart
{
public int accept(Shopper visit);
}
