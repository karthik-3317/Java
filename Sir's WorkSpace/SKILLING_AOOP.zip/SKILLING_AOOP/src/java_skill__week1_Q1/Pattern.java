package java_skill__week1_Q1;
public interface Pattern {
	public Integer postfix(String x);
}


