
package java_skill__week1_Q1;
import java.util.*;
public class a
{
	public static void main(String args[])
	{
		 Scanner sc=new Scanner(System.in);
		 String x=sc.next();
		 b post=new b();
		 post.postfix(x);
		 System.out.println(post.postfix(x));
	}
}

