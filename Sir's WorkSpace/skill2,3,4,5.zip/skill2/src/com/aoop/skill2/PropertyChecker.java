package com.aoop.skill2;

public interface PropertyChecker<T> {
    boolean check(T element);
}